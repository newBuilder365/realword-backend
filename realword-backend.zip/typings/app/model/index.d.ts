// This file is created by egg-ts-helper@1.30.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportArticle = require('../../../app/model/article');
import ExportComment = require('../../../app/model/comment');
import ExportLike = require('../../../app/model/like');
import ExportProfile = require('../../../app/model/profile');
import ExportSubscription = require('../../../app/model/subscription');
import ExportUser = require('../../../app/model/user');
import ExportVideo = require('../../../app/model/video');
import ExportView = require('../../../app/model/view');

declare module 'egg' {
  interface IModel {
    Article: ReturnType<typeof ExportArticle>;
    Comment: ReturnType<typeof ExportComment>;
    Like: ReturnType<typeof ExportLike>;
    Profile: ReturnType<typeof ExportProfile>;
    Subscription: ReturnType<typeof ExportSubscription>;
    User: ReturnType<typeof ExportUser>;
    Video: ReturnType<typeof ExportVideo>;
    View: ReturnType<typeof ExportView>;
  }
}
